<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>admin_offer</title>
    <Link rel="stylesheet" type="text/css" href="admin_offer.css">
</head>
<body>
<img src="1001.PNG">




<ul>
    <li><a class="active" href="#home">home</a></li>
    <li><a href="#University">University</a></li>
    <li><a href="#Course">Course</a></li>
    <li><a href="admin_offer.html">Student Offer</a></li>

    <form class="F1" action="demo_form.php"method="get">
        Email Address: <input type="search" name="search1"/>
        <input type="submit">
    </form>
</ul>

<table>
    <tr>
        <th>student information</th>
    </tr>
    <tr>
        <th>Student Name: <a href="Letter of recommendation.html">John Connor</a>,   University: University of Eastern Sydney<br> Phone:01145587, Course Type: Master <br> Email:sample@gamil.com<br></th>
    </tr>
    <tr>
        <th>Student Name: <a href="Letter of recommendation.html">John Connor</a>,   University: University of Eastern Sydney<br> Phone:01145587, Course Type: Master <br> Email:sample@gamil.com<br></th>
    </tr>
    <tr>
        <th>Student Name: <a href="Letter of recommendation.html">John Connor</a>,   University: University of Eastern Sydney<br> Phone:01145587, Course Type: Master <br> Email:sample@gamil.com<br></th>
    </tr>
    <tr>
        <th>Student Name: <a href="Letter of recommendation.html">John Connor</a>,   University: University of Eastern Sydney<br> Phone:01145587, Course Type: Master <br> Email:sample@gamil.com<br></th>
    </tr>
    <tr>
        <th>Student Name: <a href="Letter of recommendation.html">John Connor</a>,   University: University of Eastern Sydney<br> Phone:01145587, Course Type: Master <br> Email:sample@gamil.com<br></th>
    </tr>
    <tr>
        <th>Student Name: <a href="Letter of recommendation.html">John Connor</a>,   University: University of Eastern Sydney<br> Phone:01145587, Course Type: Master <br> Email:sample@gamil.com<br></th>
    </tr>
</table>

</body>
</html>
